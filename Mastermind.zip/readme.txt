Dans le cas d'une partie solo, seul le lancement de l'exe est requis

Dans le cas d'un 1V1, le server node js doit etre lanc� en premier suivant de deux clients